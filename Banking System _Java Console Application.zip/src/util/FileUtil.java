package util;

import model.BankData;
import model.Account;
import model.Transaction;

import java.io.*;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FileUtil {

    private static final String FILE_NAME = "bank-data.dat";

    // Save accounts and transactions to file
    public static void saveData(Map<Long, Account> accounts,
                                List<Transaction> transactions) {

        BankData bankData = new BankData(accounts, transactions);

        try (ObjectOutputStream oos =
                     new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {

            oos.writeObject(bankData);

        } catch (IOException e) {
            // In real systems, this would be logged
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    // Load accounts and transactions from file
    public static BankData loadData() {

        File file = new File(FILE_NAME);

        if (!file.exists()) {
            // First run: return empty data
            return new BankData(new HashMap<>(), new ArrayList<>());
        }

        try (ObjectInputStream ois =
                     new ObjectInputStream(new FileInputStream(FILE_NAME))) {

            return (BankData) ois.readObject();

        } catch (IOException | ClassNotFoundException e) {
            // If file is corrupted or incompatible
            System.err.println("Error loading data: " + e.getMessage());
            return new BankData(new HashMap<>(), new ArrayList<>());
        }
    }
}
