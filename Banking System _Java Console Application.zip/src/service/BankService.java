package service;

import exception.InsufficientBalanceException;
import model.Account;
import model.Transaction;
import model.BankData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import exception.AccountNotFoundException;
import util.FileUtil;

public class BankService {
    private Map<Long,Account> accounts;
    private List<Transaction> transactions;
    public BankService() {
        BankData data = FileUtil.loadData();
        this.accounts = data.getAccounts();
        this.transactions = data.getTransactions();
    }

    public void createAccount(long accountNumber,
                              String holderName,
                              double initialBalance) {

        if (accounts.containsKey(accountNumber)) {
            throw new IllegalArgumentException(
                    "Account already exists: " + accountNumber
            );
        }

        if (initialBalance < 0) {
            throw new IllegalArgumentException(
                    "Initial balance cannot be negative"
            );
        }

        Account account =
                new Account(accountNumber, holderName, initialBalance);

        accounts.put(accountNumber, account);
        FileUtil.saveData(accounts, transactions);

    }
    public void deposit(long accountNumber, double amount)
            throws AccountNotFoundException {

        Account account = accounts.get(accountNumber);

        if (account == null) {
            throw new AccountNotFoundException(
                    "Account not found: " + accountNumber
            );
        }

        if (amount <= 0) {
            throw new IllegalArgumentException(
                    "Deposit amount must be greater than zero"
            );
        }


        double newBalance = account.getBalance() + amount;
        account.setBalance(newBalance);

        Transaction transaction = new Transaction(
                "TXN-" + System.currentTimeMillis(),
                accountNumber,
                "DEPOSIT",
                amount
        );

        transactions.add(transaction);
        FileUtil.saveData(accounts, transactions);

    }
    public void withdraw(long accountNumber, double amount)
            throws AccountNotFoundException, InsufficientBalanceException
    {
        Account account=accounts.get(accountNumber);
        if (account == null) {
            throw new AccountNotFoundException(
                    "Account not found: " + accountNumber
            );
        }
        if (amount <= 0) {
            throw new IllegalArgumentException(
                    "Withdraw amount must be greater than zero"
            );
        }
        if (amount > account.getBalance()) {
            throw new InsufficientBalanceException(
                    "Insufficient balance. Available:  "+account.getBalance()
            );
        }
        double newBalance = account.getBalance() - amount;
        account.setBalance(newBalance);

        Transaction transaction = new Transaction(
                "TXN-" + System.currentTimeMillis(),
                accountNumber,
                "WITHDRAW",
                amount
        );
        transactions.add(transaction);
        FileUtil.saveData(accounts, transactions);

    }
    public void transfer(long fromAccountNumber,long toAccountNumber,double amount)
            throws AccountNotFoundException,InsufficientBalanceException
    {
        Account fromAccount=accounts.get(fromAccountNumber);
        Account toAccount=accounts.get(toAccountNumber);
        if (fromAccount == null) {
            throw new AccountNotFoundException(
                    "Account not found: " + fromAccountNumber
            );
        }
        if (toAccount == null) {
            throw new AccountNotFoundException(
                    "Account not found: " + toAccountNumber
            );
        }
        if(fromAccountNumber== toAccountNumber)
        {
            throw new IllegalArgumentException(
                    "Self Transfer Not possible"
            );
        }

        if (amount <= 0) {
            throw new IllegalArgumentException(
                    "Transfer amount must be greater than zero"
            );
        }
        if (amount > fromAccount.getBalance() ) {
            throw new InsufficientBalanceException(
                    "Account Does not Contain Sufficient Amount for transfer\n" +
                            "Your Balance is: "+fromAccount.getBalance()
            );
        }
        double fromBalance = fromAccount.getBalance() - amount;
        fromAccount.setBalance(fromBalance);
        double toBalance= toAccount.getBalance() +amount;
        toAccount.setBalance((toBalance));

        Transaction debitTransaction = new Transaction(
                "TXN-" + System.currentTimeMillis(),
                fromAccountNumber,
                "TRANSFER_DEBIT",
                amount
            );

        transactions.add(debitTransaction);
        Transaction creditTransaction = new Transaction(
                "TXN-" + System.currentTimeMillis(),
                toAccountNumber,
                "TRANSFER_CREDIT",
                amount
        );
        transactions.add(creditTransaction);
        FileUtil.saveData(accounts, transactions);


    }
    public  Account viewAccount(long accountNumber) throws AccountNotFoundException
    {
        Account account=accounts.get(accountNumber);
        if(account==null) throw new AccountNotFoundException("Account not fount with Account Number :"+accountNumber);
        return account;
    }
    public List<Transaction> getTransactions(long accountNumber)
            throws AccountNotFoundException
    {
        Account account=accounts.get(accountNumber);
        if(account==null) throw new AccountNotFoundException("Account not fount with Account Number :"+accountNumber);
        List<Transaction> transactionList =new ArrayList<>();
        for(Transaction transaction:transactions)
        {
            if(transaction.getAccountNumber() == accountNumber)
            {
                transactionList.add(transaction);
            }

        }
        return  transactionList;
        

    }

}
