package model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class BankData implements Serializable {

    private static final long serialVersionUID = 1L;

    private Map<Long, Account> accounts;
    private List<Transaction> transactions;

    public BankData(Map<Long, Account> accounts,
                    List<Transaction> transactions) {
        this.accounts = accounts;
        this.transactions = transactions;
    }

    public Map<Long, Account> getAccounts() {
        return accounts;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }
}
