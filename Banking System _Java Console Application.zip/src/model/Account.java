package model;

import java.io.Serializable;

public class Account implements Serializable
{
    private static final long serialVersionUID = 1L;
    private long accountNumber;
    private String holderName;
    private double balance;
    public Account(long accountNumber,String holderName,double balance)
    {
        this.accountNumber=accountNumber;
        this.holderName=holderName;
        this.balance=balance;
    }
    public long getAccountNumber()
    {
        return accountNumber;
    }
    public void setAccountNumber(long accountNumber) {this.accountNumber=accountNumber;}
    public String getHolderName()
    {
        return holderName;
    }
    public void setHolderName(String holderName)
    {
        this.holderName=holderName;
    }
    public double getBalance()
    {
        return balance;
    }
    public void setBalance(double balance)
    {
        this.balance=balance;
    }
    @Override
    public String toString() {
        return "AccountNumber: " + accountNumber +
                ", HolderName: " + holderName +
                ", Balance: " + balance;
    }


}
