import exception.AccountNotFoundException;
import exception.InsufficientBalanceException;
import model.Account;
import model.Transaction;
import service.BankService;
import java.util.Scanner;
import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        BankService bankService=new BankService();
        int n=0;
        while(n!=7)
        {

            System.out.println("===== Banking System =====\n" +
                    "1. Create Account\n" +
                    "2. Deposit\n" +
                    "3. Withdraw\n" +
                    "4. Transfer\n" +
                    "5. View Account\n" +
                    "6. View Transactions\n" +
                    "7. Exit\n" +
                    "Enter choice:");
            n = sc.nextInt();
            switch(n) {
                case 1:
                {
                    try {
                        System.out.println("Enter the Account Number:");
                        long accountNumber = sc.nextLong();
                        sc.nextLine();
                        System.out.println("Enter your Name: ");
                        String name = sc.nextLine();
                        System.out.println("Enter Initial Balance: ");
                        double balance = sc.nextDouble();
                        bankService.createAccount(accountNumber, name, balance);
                    }
                    catch(IllegalArgumentException I)
                    {
                        System.out.println(I.getMessage());
                    }
                    break;


                }
                case 2:
                {
                    try{
                        System.out.println("Enter the Account Number:");
                        long accountNumber = sc.nextLong();
                        sc.nextLine();
                        System.out.println("Enter the Amount: ");
                        double amount= sc.nextDouble();
                        sc.nextLine();
                        bankService.deposit(accountNumber,amount);
                    }
                    catch (AccountNotFoundException | IllegalArgumentException A)
                    {
                        System.out.println(A.getMessage());
                    }
                    break;
                }
                case 3:
                {
                    try{
                        System.out.println("Enter the Account Number:");
                        long accountNumber = sc.nextLong();
                        sc.nextLine();
                        System.out.println("Enter the Amount: ");
                        double amount= sc.nextDouble();
                        sc.nextLine();
                        bankService.withdraw(accountNumber,amount);
                    }
                    catch (AccountNotFoundException | IllegalArgumentException | InsufficientBalanceException  I)
                    {
                        System.out.println(I.getMessage());
                    }
                    break;
                }
                case 4:
                {
                    try {
                        System.out.println("Enter Your Account Number:");
                        long fromaccountNumber = sc.nextLong();
                        sc.nextLine();
                        System.out.println("Enter the Account Number of the recipient:");
                        long toaccountNumber = sc.nextLong();
                        sc.nextLine();
                        System.out.println("Enter the Amount:");
                        double amount = sc.nextDouble();
                        sc.nextLine();
                        bankService.transfer(fromaccountNumber, toaccountNumber, amount);
                    }
                    catch (AccountNotFoundException | IllegalArgumentException | InsufficientBalanceException  I)
                    {
                        System.out.println(I.getMessage());
                    }
                    break;
                }
                case 5:
                {
                    try {
                        System.out.println("Enter the Account Number:");
                        long accountNumber = sc.nextLong();
                        sc.nextLine();
                        System.out.println("Account Details:");
                        System.out.println(bankService.viewAccount(accountNumber));
                    }
                    catch (AccountNotFoundException A)
                    {
                        System.out.println(A.getMessage());
                    }
                }
                break;
                case 6:
                {
                    {
                        try {
                            System.out.println("Enter the Account Number:");
                            long accountNumber = sc.nextLong();
                            sc.nextLine();
                            List<Transaction> list = bankService.getTransactions(accountNumber);

                            if (list.isEmpty()) {
                                System.out.println("No transactions found.");
                            } else {
                                for (Transaction t : list) {
                                    System.out.println(t);
                                }
                            }

                        }
                        catch (AccountNotFoundException A)
                        {
                            System.out.println(A.getMessage());
                        }
                    }
                }
                break;
                case 7:
                {
                    System.out.println("You have Exited the Main Menu");
                    sc.close();
                    return;

                }
            }
        }
    }
}